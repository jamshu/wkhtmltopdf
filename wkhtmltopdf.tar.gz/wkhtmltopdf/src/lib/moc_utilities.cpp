/****************************************************************************
** Meta object code from reading C++ file 'utilities.hh'
**
** Created: Wed Jun 25 09:37:26 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "utilities.hh"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'utilities.hh' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyLooksStyle[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   14,   13,   13, 0x0a,
      42,   37,   13,   13, 0x0a,
      66,   37,   13,   13, 0x0a,
      97,   37,   13,   13, 0x0a,
     124,   37,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyLooksStyle[] = {
    "MyLooksStyle\0\0f\0producingForms(bool)\0"
    "path\0setCheckboxSvg(QString)\0"
    "setCheckboxCheckedSvg(QString)\0"
    "setRadioButtonSvg(QString)\0"
    "setRadioButtonCheckedSvg(QString)\0"
};

void MyLooksStyle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyLooksStyle *_t = static_cast<MyLooksStyle *>(_o);
        switch (_id) {
        case 0: _t->producingForms((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->setCheckboxSvg((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->setCheckboxCheckedSvg((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->setRadioButtonSvg((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->setRadioButtonCheckedSvg((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyLooksStyle::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyLooksStyle::staticMetaObject = {
    { &QProxyStyle::staticMetaObject, qt_meta_stringdata_MyLooksStyle,
      qt_meta_data_MyLooksStyle, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyLooksStyle::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyLooksStyle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyLooksStyle::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyLooksStyle))
        return static_cast<void*>(const_cast< MyLooksStyle*>(this));
    return QProxyStyle::qt_metacast(_clname);
}

int MyLooksStyle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QProxyStyle::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
